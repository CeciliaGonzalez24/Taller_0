package taller_0;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.File;


/** 
 * @author Cecilia Gonzalez 
 */
public class Taller_0 {
    
    public static void leerJugadores(String matrizJugadores[][],int cantidades[]) throws FileNotFoundException{
        File fileJugador = new File("Jugadores.txt");
        Scanner arch = new Scanner(fileJugador);
        int cantJugadores = 0;
        
        while (arch.hasNextLine()){
            String[] partes= arch.nextLine().split(",");
            String nombreJugador=partes[0];
            String contraseña=partes[1];
            String hp = partes[2];
            String atk = partes[3];
            String def = partes[4];
            String vel = partes[5];
            String cantHechizos = partes[6];
            String exp = partes[7];
            matrizJugadores[cantJugadores][0]=nombreJugador;
            matrizJugadores[cantJugadores][1]=contraseña;
            matrizJugadores[cantJugadores][2]=hp;
            matrizJugadores[cantJugadores][3]=atk;
            matrizJugadores[cantJugadores][4]=def;
            matrizJugadores[cantJugadores][4]=vel;
            matrizJugadores[cantJugadores][4]=cantHechizos;
            matrizJugadores[cantJugadores][4]=exp;
            cantJugadores++;
        }
        cantidades[0]=cantJugadores;
    }
    
    public static void leerEnemigos(String matrizEnemigos[][],int cantidades[]) throws FileNotFoundException{
        File fileEnemigos = new File("Enemigos.txt");
        Scanner arch1 = new Scanner(fileEnemigos);
        int cantEnemigos = 0;
        while (arch1.hasNextLine()){
            String[] partes= arch1.nextLine().split(",");
            String nombreEnemigo=partes[0];           
            String hpEnemigo = partes[1];
            String atkEnemigo = partes[2];
            String tipoClase = partes[3];
            String velEnemigo = partes[4];           
            matrizEnemigos[cantEnemigos][0]=nombreEnemigo;
            matrizEnemigos[cantEnemigos][1]=hpEnemigo;
            matrizEnemigos[cantEnemigos][2]=atkEnemigo;
            matrizEnemigos[cantEnemigos][3]=tipoClase;
            matrizEnemigos[cantEnemigos][4]=velEnemigo;
            cantEnemigos++;  
            
        }
        cantidades[1]=cantEnemigos;
    }

    public static void leerHechizos(String matrizHechizos[][], int cantidades[])throws FileNotFoundException{
        File fileHechizo = new File("Hechizos.txt");
        Scanner arch2 = new Scanner(fileHechizo);
        int cantHechizos = 0;
        while (arch2.hasNextLine()){
            String[] partes= arch2.nextLine().split(",");
            String nombreHechizo=partes[0];           
            String atkHechizo = partes[1];          
            matrizHechizos[cantHechizos][0]=nombreHechizo;
            matrizHechizos[cantHechizos][1]=atkHechizo;           
            cantHechizos++;  
            
        }
        cantidades[2]=cantHechizos;
    }
      
    public static void leerHechizoJugador(String matrizHechizosJugador[][], int cantidades[],String matrizJugadores[][])throws FileNotFoundException{
        File fileHechizoJugador = new File("HechizoJugador.txt");
        Scanner arch3 = new Scanner(fileHechizoJugador);
        int cantHechizosJugador = 0;
        while (arch3.hasNextLine()){
            String[] partes= arch3.nextLine().split(",");
            String nomJugador=partes[0];                                
            matrizHechizoJugador[cantHechizosJugador][0]=nomJugador;
            int pos=i;
            for(int i =0;i<cantidades[0];i++){
                if(matrizJugadores[i][0].equals(nomJugador))
                    pos=i;
            }
            int cont=0;
            for(int j=0;j<Int.parseInt(matrizJugadores[pos][6]);j++){
                String nomHechizo = partes[cont+1];
                matrizHechizoJugador[cantHechizosJugador][cont+1]=nomHechizo;
            }                                   
            cantHechizosJugador++;              
        }
        cantidades[3]=cantHechizosJugador;
    }
    
    public static void agregarEnemigo(String matrizEnemigos[][],int cantidades[]){
        System.out.println("Nombre del Enemigo: ");
        Scanner scan =new Scanner(System.in);
        String nomEnemigo = scan.nextLine();
        System.out.println();
        String existe = "false";      
        int cantenemigos=cantidades[1];
        while(!existe.equals("true")){
            for(int i =0;i<cantidades[1];i++){
                if(matrizEnemigos[i][0].equals(nomEnemigo)){
                    System.out.println("El enemigo ya existe");
                    break;
                }
                else{
                    int cont=0;
                    System.out.println("Vida del Enemigo: ");
                    String hpEnemigo = scan.nextLine();     
                    matrizEnemigos[cantenemigos+1][cont]=hpEnemigo;
                    cont++;
                    System.out.println("Ataqie del Enemigo: ");
                    String atkEnemigo = scan.nextLine();
                    matrizEnemigos[cantenemigos+1][cont]=atkEnemigo;
                    cont++;
                    System.out.println("Tipo de clase del Enemigo: ");
                    String claseEnemigo = scan.nextLine();
                    matrizEnemigos[cantenemigos+1][cont]=claseEnemigo;
                    cont++;
                    System.out.println("Velocidad del Enemigo: ");
                    String velEnemigo = scan.nextLine();
                    matrizEnemigos[cantenemigos+1][cont]=velEnemigo;
                                                                                                
                    cantidades[1]=cantidades[1]+1;
                }
            }
        }
    }  
    
    public static void agregarHechizo(String matrizHechizos[][],int cantidades[]){
        System.out.println("Nombre del Hechizo: ");
        Scanner scan =new Scanner(System.in);
        String nomHechizo = scan.nextLine();
        System.out.println();
        String existe = "false";      
        int canthechizo=cantidades[2];
        while(!existe.equals("true")){
            for(int i =0;i<cantidades[2];i++){
                if(matrizHechizos[i][0].equals(nomHechizo)){
                    System.out.println("El hechizo ya existe");
                    break;
                }
                else{
                    int cont=0;
                    System.out.println("Poder de ataque del Hechizo: ");
                    String atkHechizo = scan.nextLine();     
                    matrizHechizos[canthechizo+1][cont]=atkHechizo;                                   
                    cont++;                                                                                                                 
                    cantidades[2]=cantidades[2]+1;
                }
            }
        }
    }  
    
    public static void menuAdmin(String matrizJugadores[][],String matrizEnemigos[][],String matrizHechizos[][],int cantidades[]){
        System.out.println("----BIENVENIDO A MENU ADMIN----");              
        System.out.println("-- a) Eliminar Jugador: ");      
        System.out.println("-- b) Agregar Enemigos: ");        
        System.out.println("-- c) Agregar Hechizos: ");      
        System.out.println("-- d) Ver Estadistica Jugador: ");  
        Scanner scan =new Scanner(System.in);
        System.out.println("--Eliga Opcion: (a,b,c,d) ");      
        String opcion =scan.nextLine();
        switch (opcion) {
            case "a":
                break;
            case "b":
                agregarEnemigo(matrizEnemigos,cantidades);
                break;
            case "c":
                agregarHechizo(matrizHechizos,cantidades);
                break;
            case "d":
                break;
            default:
                break;
        }                              
    }
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        String matrizEnemigos[][]  =new String[100][5];
        String matrizJugadores[][]  =new String[100][8];
        String matrizHechizos[][]  =new String[100][2];
        String matrizHechizosJugador[][]  =new String[100][20];
        //[cantJugadores,cantEnemigos,cantHechizos]
        int cantidades[]=new int[3];
        leerEnemigos(matrizEnemigos,cantidades); 
        leerJugadores(matrizJugadores,cantidades);
        leerHechizos(matrizHechizos,cantidades);
        leerHechizoJugador(matrizHechizosJugador,cantidades,matrizJugadores);
              
        System.out.println(matrizJugadores[1][0]+matrizJugadores[1][3]+matrizJugadores[2][0] );      
        System.out.println("----INICIANDO SESION---");
        Scanner scan =new Scanner(System.in);
        System.out.println("--Ingrese nombre de Usuario: ");      
        String usuario =scan.nextLine();
        if(usuario.equals("Admin")){
            System.out.println("--Ingrese contraseña de Usuario: ");      
                    String contraseña =scan.nextLine();  
                    if(contraseña.equals("Patata19")){
                        menuAdmin(matrizJugadores,matrizEnemigos,matrizHechizos,cantidades);
                    }
        }else{
            for(int i =0;i<cantidades[0];i++){
                if(matrizJugadores[i][0].equals(usuario)){
                    System.out.println("--Ingrese contraseña de Usuario: ");      
                    String contraseña =scan.nextLine();                
                    for(int j =0;j<cantidades[0];j++){                                       
                        if(matrizJugadores[j][1].equals(contraseña)){                         
                            System.out.println("----BIENVENIDO A MAO---");
                        }              
                    }
                }       
            } 
        }      
        
        
    }
    
}
